#ifndef NEWFILE_H
#define	NEWFILE_H

#include "mcc_generated_files/mcc.h"
void bpm(void);
extern int SYS, DIA, PPM;

#endif
